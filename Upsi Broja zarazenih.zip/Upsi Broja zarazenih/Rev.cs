﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upsi_Broja_zarazenih
{
    internal class Rev
    {

        DateTime datumUpisaUBazu;


        public int Year { get; set; }
        public int Month { get; set; }
        public double Zarazeni { get; set; }
       
    
    }
}
